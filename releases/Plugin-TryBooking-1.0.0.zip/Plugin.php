<?php

namespace WebApps\Plugin;

use App\Models\Plugin;

class TryBooking_Plugin extends Plugin
{
    public $name;
    public $icon;
    public $version;
    public $author;

    public function __construct(array $attributes = [])
    {
        parent::__construct($attributes);
        $plugin = json_decode(file_get_contents(__DIR__ . '/plugin.json'), true);
        $this->name = $plugin['name'];
        $this->icon = $plugin['icon'];
        $this->version = $plugin['version'];
        $this->author = $plugin['author'];
    }

    public $options = [
        'items' => [
            'type' => 'repeater',
            'label' => 'Booking',
            'ref' => 'bookingName',
            'options' => [
                'bookingID' => [
                    'type' => 'text',
                    'label' => 'Enter the ID of the booking',
                    'maxLength' => 255,
                    'required' => true,
                ],
                'bookingName' => [
                    'type' => 'text',
                    'label' => 'Enter the name of the booking',
                    'maxLength' => 255,
                    'required' => false,
                ],
                'bookingDesc' => [
                    'type' => 'text',
                    'label' => 'Enter the description of the booking',
                    'maxLength' => 255,
                    'required' => true,
                ],
            ]
        ]
    ];

    public $new = [
        'items' => [['bookingID' => '', 'bookingName' => '', 'bookingDesc' => '']]
    ];

    public $preview = [
        'before' => '<div class="tb-header">
                        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJoAAAAjCAMAAABb5OOYAAAABGdBTUEAALGPC/xhBQAAACBjSFJN
                        AAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAA6lBMVEVHcEz/////////////
                        ////////////////////////////////////////////////////////////////////////////
                        ////////////////////////////////////////////////////////////////////////////
                        ////////////////////////////////////////////////////////////////////////////
                        ///////////////////////////////////////////////////////////////////ZxWggAAAA
                        TXRSTlMAAgYEEGvLx60KK9zj4EuQDTFXk1VmtbOxJk9jQ/dIvpc22hPtofo01B/wpHl1GM87ASII
                        U3Kq1xx8ucOajPNu6ij+noDmXF71RYaJQWwRhe8AAAABYktHRAH/Ai3eAAAAB3RJTUUH5QUHDCEV
                        NzKfNAAABWVJREFUWMO9mAlX4jAQgNOClKNcgoACWi0WpCA35RaQYwH7///OzuQoBY+F9T3mPWmS
                        ptMvkzlSCTlDJBnEc/p0L8rp838jVz5FUfyBU6cHQ2pYVSMXQYvaIGrs1OlxnG5fXwQtga8KnYmW
                        PBy8SaXTmdsTNdxls9nTXpeL5s9Bi90/fEbTEPfxRA1PMPfEZeiFc9AIef6Mhk5hFE98vnQ62kv5
                        PDTzl1a7LFquUq1WX89Ai18M7SypwfP136A1jvrSeWh607vvtJrUolIDlHqLIXj+Koj65HgumWx7
                        SbPT7QZIM9lG0UmcNiIyQ7PkiJk274SuXn+gDM2kk/MjpqIMtbobraglUEbo/EEtER1lmthKg4zJ
                        oz88CSXEct9qk2mq+DKA1G6SJE0+ttVCo+SxOUtCHM695I3dqZN3ei3o3Gqsu2C67pds1gNzH/mZ
                        decLF9qKjdlrGGnbIgxyOK22ntABk1m6QjtlGiqhQ7Q/0JpU8bf8LZoQaphmQXTTVPnCub3ao62P
                        0eY5jmaXDb6UGdU24TPn8BcmOQtNFe7KuDkWUBnUdIaXXONOG7Ug6WPmmz54BVrNh78JVIbrKyQy
                        2N9A93WKBtxiYJVaDlpzhYsrd3Ex8S5OuUeOrYqPlXamIVaShUZ+cT2kdrwjUgsVRaivSK8jCh3O
                        +B9iRNItUNhsEGmDz3oaHC0qkTFcFOgHAHreJsSPw6AgyZhe0COK+zCIh2EzNtydhhyNEKwVJhwW
                        BnC9wYEdNJ4hLpbcxDR55PhzeNN+13mYRXl13omijmiFHrwLLF6D1dxCXwVr3uGOcl8ZE4a6ctDq
                        QFoWb2goDhpCFvlrKBo6ageuXTFQ4ruBMj6o33XkhIAuMZswtCe4PcsztEdALMG6P9CKMlsZ6sZz
                        QJajbZpTF9lXaAk3WtXN6jtC0xwtMqQ8NUAeYXvqB3kt6EaLMZeugXNtOZq2R5uj5xWE/k9ojz+i
                        pY/QOvsEuKDRBL816Vu0J++PaAZG3ZD8H1rqCO1qr6cIr140fOyB/0ObVyGY7N1PaNH/QfPAjg6D
                        c3tyu0d74mjoY1+hvR2i2ZtinveO0VLc16qCxDwDjfQhoUG8pIjLaoAyg/y3hPxfhJRkxVgYIBqG
                        QeUoDNqkg4nciYOBg4ZG+oBrhxPR3C6M7qDlvkELGjQzr1xo5RdAM5i1sBgsIdVEMNM22Po1njzW
                        TvKgr1SbXEfGQRPFH9G2OLDl6VFxo33w57ZikItEMzO+ncprgZnjxmaRgSkXzEIwU48Iy28hnZWv
                        OrcL3G5hcvXpe7SNY7W2Gw0bajHQmbvRMhEMwV4VSVIV1/m4arPcRqXdxZoyiY6xKHQJN/10+466
                        8KOO5nFlZ7Gi0ExhtzSW6IC9RPiZhRGrmuCnFmpZJnQflq6CorM8ak/CtCJRND+t8/h1WefV9W2P
                        hhV3LrY7aruEnsNmoiDbDx6xbibX4ovKrlH3winEGfPx8g5RdvuHXifguvKQjeUF2pUtqvEXaLjv
                        lszb9GOvy16UYSe0uyl7ROmx+OP0+QpxoaU+oSksdLB1y1ZXxlNVEE8U9mgk0AKaahhQzqEk+jNU
                        7l1WKztHM9hQDSQi94chZdESE7YDn697I7okpw18qR090L9W+pVKpb8m7QVcKll0aO8KZQ3OpvNW
                        LEkbbapBv9KiERro3OP1Xk+XyJcCO5QPHg9KsYN/ZMjy4W2Z/FI0+zAYvxSPwvbhMiI+MoaudPat
                        wOkHz2MXEk+VbtDGYFHxk/SuIXqN3WX+oYJSy7+/ZWlqyvxjZluE2KVEEanHqJ+G5rsYmp+TTbL/
                        mpmzSqWSpYwvhhbLdktTVUnQcvQX43LVBPAG9IEAAAAldEVYdGRhdGU6Y3JlYXRlADIwMjEtMDUt
                        MDdUMTI6MzM6MjErMDM6MDChpl3lAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDIxLTA1LTA3VDEyOjMz
                        OjIxKzAzOjAw0PvlWQAAAABJRU5ErkJggg==" alt="TryBooking"/>
                        <div class="tb-dropout">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
                            </svg>
                        </div>
                    </div>',
        'items' => [
            'each' => '<div class="item">
                            <a id="item{index}" href="https://www.trybooking.co.uk/{value.bookingID}" target="_blank" class="box-slide">
                                <div class="reveal-content">{value.bookingName}&nbsp;</div>
                            </a>
                            <div class="desc" data-val="value.bookingDesc"></div>
                       </div>'
        ],
    ];

    public function output($edit = false)
    {
        $this->edit = $edit;
        ob_start();
        require(__DIR__.'/include/_html.php');
        $html = str_replace(["\r", "\n", "\t"], '', trim(ob_get_clean()));
        $html = preg_replace('/(\s){2,}/s', '', $html);
        return $html;
    }

    public function style()
    {
        return file_get_contents(__DIR__.'/include/_style.css');
    }

    public function scripts($edit = false)
    {
        return '';
    }
}
